// MSP430F55xx_pulse_counter_main.c
//
// original development :
//  '5528 and an MSP-TS430RGC64USB target board
//  count negative pulses on P1.6/pin24 - internal pullup is used,
//  so P1.6/pin24 is normally HIGH


#include <msp430.h>				


volatile int count_in_progress;
volatile unsigned TA1Rread;

// prototypes
void begin_counting( unsigned target_count );


// ISRs
#pragma vector=TIMER1_A0_VECTOR
__attribute__((interrupt)) void timer1_a0_ISR( void )
{
    // this is the vector for CCIFG in TA1CCTL0 register

    // read TA1R
    TA1Rread = TA1R;

    // toggle the LED
    P1OUT ^= BIT0;

    // reset count-in-progress flag
    count_in_progress = 0;

    // lastly, reset the int-pending flag
    TA1CCTL0 &= ~CCIFG;
}



void begin_counting( unsigned target_count)
{

    // stop counting - clear lower bit of MC field
    TA1CTL &= ~BIT4;
    // set current count
    TA1R = 0;
    // set the desired pulse count
    TA1CCR0 = target_count;
    // clear CCIFG - table 17-6 of SLAU208
    TA1CCTL0 &= ~CCIFG;
    // resume counting - set lower bit of MC field
    TA1CTL |= BIT4;
}


void main(void)
{
	WDTCTL = WDTPW | WDTHOLD;		// stop watchdog timer
	P1DIR |= 0x01;					// set P1.0 as output (an LED is attached to pin)

	// enable pull on p1.6
	P1REN |= BIT6;
	// set pull to be "up"
	P1OUT |= BIT6;

	// TA1CTL - MC is 01 binary for count-up mode
	TA1CTL = 0x10;

	// set P1SEL.6 so that P1.6 functions as TA1CLK input
	// see table 6-46 of SLAS590
	P1SEL |= BIT6;

	// enable capture/compare interrupts for TIMER1 A0
	TA1CCTL0 |= CCIE;

	// enable interrupts in general
    _enable_interrupts();


	for(;;)
	{

	    if (!count_in_progress)
	    {
	        count_in_progress = 1;
	        begin_counting( 80 );
	    }
	    else
	    {
	        TA1Rread = TA1R;
	        TA1Rread = TA1Rread;
	    }


    } // end for(ever)

}  // end main()
